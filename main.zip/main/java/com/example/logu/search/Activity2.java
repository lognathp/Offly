package com.example.logu.search;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.method.ScrollingMovementMethod;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

public class Activity2 extends AppCompatActivity {

public TextView tv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_2);
        TextView tv = (TextView) findViewById(R.id.textView);
        String data = readTextFile(this, R.raw.amsterdam);
        String data1 = readTextFile(this,R.raw.bleedingout);
        String data2 = readTextFile(this,R.raw.demons);
        String data3 = readTextFile(this,R.raw.everynight);
        String data4 = readTextFile(this,R.raw.fallen);
        String data5 = readTextFile(this,R.raw.hearme);
        String data6 = readTextFile(this,R.raw.itstime);
        String data7 = readTextFile(this,R.raw.onthetopoftheworld);
        String data8 = readTextFile(this,R.raw.radioactive);
        String data9 = readTextFile(this,R.raw.rocks);
        String data10 = readTextFile(this,R.raw.smoke);
        String data11 = readTextFile(this,R.raw.tiptoe);
        String data12 = readTextFile(this,R.raw.underdog);
        String data13 = readTextFile(this,R.raw.workingman);
        Intent i = getIntent();
        String str = i.getStringExtra("s");
        if (str.equalsIgnoreCase("Amsterdam")) {
            tv.setText(data);
            tv.setMovementMethod(new ScrollingMovementMethod());
        }
        else if (str.equalsIgnoreCase("Bleeding Out"))
        {
            tv.setText(data1);
            tv.setMovementMethod(new ScrollingMovementMethod());

        }
        else if (str.equalsIgnoreCase("Demons"))
        {
            tv.setText(data2);
            tv.setMovementMethod(new ScrollingMovementMethod());

        }
        else if (str.equalsIgnoreCase("Every Night"))
        {
            tv.setText(data3);
            tv.setMovementMethod(new ScrollingMovementMethod());
        }
        else if (str.equalsIgnoreCase("Fallen"))
        {
            tv.setText(data4);
            tv.setMovementMethod(new ScrollingMovementMethod());

        }
        else if (str.equalsIgnoreCase("Hear Me"))
        {
            tv.setText(data5);
            tv.setMovementMethod(new ScrollingMovementMethod());

        }
        else if (str.equalsIgnoreCase("Its Time"))
        {
            tv.setText(data6);
            tv.setMovementMethod(new ScrollingMovementMethod());

        }
        else if (str.equalsIgnoreCase("On the top of the World"))
        {
            tv.setText(data7);
            tv.setMovementMethod(new ScrollingMovementMethod());

        }
        else if (str.equalsIgnoreCase("Radioactive"))
        {
            tv.setText(data8);
            tv.setMovementMethod(new ScrollingMovementMethod());

        }
        else if (str.equalsIgnoreCase("Rocks"))
        {
            tv.setText(data9);
            tv.setMovementMethod(new ScrollingMovementMethod());

        }
        else if (str.equalsIgnoreCase("Smoke"))
        {
            tv.setText(data10);
            tv.setMovementMethod(new ScrollingMovementMethod());

        }
        else if (str.equalsIgnoreCase("Tiptoe"))
        {
            tv.setText(data11);
            tv.setMovementMethod(new ScrollingMovementMethod());

        }
        else if (str.equalsIgnoreCase("Underdog"))
        {
            tv.setText(data12);
            tv.setMovementMethod(new ScrollingMovementMethod());

        }
        else if (str.equalsIgnoreCase("Working Man"))
        {
            tv.setText(data13);
            tv.setMovementMethod(new ScrollingMovementMethod());

        }
        else
        {
            tv.setText("Sorry");
            tv.setText("Lyrics Not Found");
        }
    }

    public static String readTextFile(Context ctx,int resId) {
        InputStream is = ctx.getResources().openRawResource(resId);
        InputStreamReader isr = new InputStreamReader(is);
        BufferedReader br = new BufferedReader(isr);
        String line;
        StringBuilder sb = new StringBuilder();
        try {
            while ((line = br.readLine()) != null) {
                sb.append(line);
                sb.append('\n');
            }
        }

        catch (IOException e) {
            return null;
        }
        return sb.toString();
    }




}


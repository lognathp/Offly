package com.example.logu.search;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;


public class MainActivity extends AppCompatActivity {
    public EditText edt;
    public String s;
    public Button b;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
                addListenerOnButton();
    }
    private void addListenerOnButton(){
        edt = (EditText)findViewById(R.id.editText);
        b = (Button)findViewById(R.id.button);
        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent myin = new Intent(getBaseContext(),Activity2.class);
                myin.putExtra("s",edt.getText().toString());
                startActivity(myin);

                                }


        });
    }
}
